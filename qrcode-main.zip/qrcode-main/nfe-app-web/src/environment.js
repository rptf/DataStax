
const production = true;

const environment = {
    production: (production ? true : false),
    apiUrl: 'https://nfe-app-infinite7.b9ad.pro-us-east-1.openshiftapps.com'
};

export default environment;