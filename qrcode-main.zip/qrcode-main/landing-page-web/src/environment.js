
const production = true;

const environment = {
    production: (production ? true : false),
    apiUrl: (production ? 'https://snoop-api-infinite7.b9ad.pro-us-east-1.openshiftapps.com/api/p/receipt' : 'http://192.168.0.114:3000/api/p/receipt'),
};

export default environment;